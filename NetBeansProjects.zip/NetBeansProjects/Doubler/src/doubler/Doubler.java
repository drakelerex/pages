/*
 * Andrew Emerick
 * 12/8/21
 * Unit 5 - Math Returns
 * Create a math return method to double a number
 */
package doubler;

import java.util.Scanner;

public class Doubler 
{
    // This is where your methods go
    // Don't use void
    // a return method needs a parameter
    public int twice(int num)
    {
        return num*2;
    }
    public int thrice(int num3)
    {
        return num3*3;
    }
    public static void main(String[] args) 
    {
        //THIS IS WHERE YOUR RUNNER GOES
        Doubler dragon = new Doubler();
        Scanner parasite = new Scanner(System.in);
        
        System.out.print("Please enter an integer: ");
        int num2 = parasite.nextInt();
        
        System.out.println("Twice your number is: " + dragon.twice(num2));
        System.out.println("Thrice your number is: " + dragon.thrice(num2));
        //System.out.println("Twice your number is: " + dragon.twice(5));
        //System.out.println("Twice your number is: " + dragon.twice(27));
        
        
    }
    
}
