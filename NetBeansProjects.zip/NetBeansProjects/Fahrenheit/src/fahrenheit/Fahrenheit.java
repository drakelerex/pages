/*
 * Andrew Emerick
 * 12/15/21
 * Convert Fahrenheit to Celsius
 */
package fahrenheit;

import java.util.Scanner;

public class Fahrenheit 
{

    public double toCelsius(double fahrenheit)
    {
        return (fahrenheit-32)*5/9;
    }
    
    public double toFahrenheit(double celsius)
    {
        return (celsius*9/5)+32;
    }
    
    public static void main(String[] args) 
    {
        Fahrenheit strider = new Fahrenheit();
        Scanner dragon = new Scanner(System.in);
        
        System.out.print("Enter a temperature in Fahrenheit: ");
        double fTemp = dragon.nextDouble();
        System.out.print("Enter what you think it is converted to Celsius: ");
        double cTemp = dragon.nextDouble();
        
        System.out.println("Your guess would be "+strider.toFahrenheit(cTemp)+" degrees Fahrenheit");
        System.out.println("The answer to your temperature converted to celsius is "+strider.toCelsius(fTemp));
    }
    
}
