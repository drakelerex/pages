/*
 * Andrew Emerick
 * 11/12/21
 * Unit 4 - notes on methods and graphics
 */
package colorrunner;

import javax.swing.JFrame;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Polygon;

public class ColorRunner extends JFrame
{

    private static final int WIDTH = 1366;
    private static final int HEIGHT = 768;
    
    public ColorRunner() 
    {
        super("Draco");
        setSize(WIDTH,HEIGHT);
        setBackground(Color.white);
        setVisible(true); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // note the cosole will now say that the application has terminated
        
    }
    
    public void paint(Graphics window)
    {
        window.setColor(Color.GREEN);
        window.drawOval(200, 100, 100, 50);
        window.fillOval(450, 400, 100, 50);
        // First parameter is how far right the object goes
        // second paramter is how far down the object goes
        // third paramater is the width of the object
        // fourth paramter is the height of the object
        window.setColor(Color.BLUE);
        window.drawString("Hello Human!", 100, 300);
        window.drawString("Ego sum computer.", 350, 50);
        window.drawLine(300, 300, 400, 400);
        window.drawLine(100, 200, 600, 200);
        //drawArc(int x, int y, int width, int height, int startAngle, int acrAngle)
        window.drawArc(500, 300, 40, 40, 90, 90);
        window.drawArc(100, 100, 50, 50, 0, -180);
        
        //this is new and CRAZY!
        int[] xPoints = {400, 200, 600};
        int[] yPoints = {700, 500, 500};
        int nPoints = 3;
        Polygon triangle = new Polygon(xPoints, yPoints, nPoints);
        
        window.setColor(Color.yellow);
        window.fillPolygon(triangle);
    }
    
    public static void main(String[] args) 
    {
        ColorRunner run = new ColorRunner(); // add before title
    }
    
}
