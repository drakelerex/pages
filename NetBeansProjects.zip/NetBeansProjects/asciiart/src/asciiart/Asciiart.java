/*
 * Andrew Emerick
 * 9/29/21
 * ASCII Art- Draw a creature/animal using ascii characters.
 */
package asciiart;

public class Asciiart {

    public static void main(String[] args) {
        System.out.println("");
        
    }
    
}
