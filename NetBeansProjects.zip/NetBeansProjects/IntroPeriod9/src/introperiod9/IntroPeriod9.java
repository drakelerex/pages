/*
 * Andrew Emerick
 * Period 9 - Unit 1 Notes
 * 9/16/2021
 */
package introperiod9;

public class IntroPeriod9 
{
    
    public static void main(String[] args) 
    {
        // Practice with the print command
        System.out.print("Taco, ");
        System.out.print("Spaghetti, ");
        System.out.print("Wings");
        //Output: Taco, Spaghetti, Wings
        
        System.out.println();  // blank line
        System.out.println(""); // blank line
                
        // Practice with the println command
        System.out.println("Mighty Taco");
        System.out.println("How I love thee");
        System.out.println("Cheese");
        //Output: Mighty Taco
        //        How I love thee
        //        Cheese
        
        // Practice with Escape Sequences
        System.out.println("\n\tMighty Taco");
        System.out.println("\t\tHow I love thee");
        System.out.println("\tCheese");
        // \n goes to the next line
        //  \t tabs
        
        System.out.println(); // prints a blank line
        System.out.println(""); // using an empty String
        
        System.out.println("\"Mighty Taco\"");
        System.out.println("\"how I love thee\"");
        System.out.println("\"Cheese\"");
        
        // all characters print to the screen except the b\
        System.out.println(); // prints a blank line
        System.out.println("!@#$%^&*(){}|\\"); // fix with \\
    }
    
}
