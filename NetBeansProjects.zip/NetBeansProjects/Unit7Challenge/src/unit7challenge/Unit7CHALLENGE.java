/**
 * Unit 7 CHALLENGE PROBLEM - Your computer processed your essay incorrectly and 
 * replaced all your spaces with @ symbols.  Create a method called getFirstWord()
 * that returns all letters up to the first @ sign.  If there is no @ sign, 
 * return "COMPLETE".  If the word starts with an @ sign, return "NO WORD".
 */
package unit7challenge;

public class Unit7CHALLENGE 
{

    public static String getFirstWord( String word)
    {
        int loc = word.indexOf("@");
        if (loc == -1) //When @ is the first character
            return "Complete";
        if (loc == 0) // when there is no @
            return "No word";
        return word.substring(0, loc);
    }
    
    public static void main(String[] args) 
    {
        System.out.println( getFirstWord("elephants@are@big"));
        System.out.println( getFirstWord("mighty@taco"));
        System.out.println( getFirstWord("@i@love@comp@sci")); //0
        System.out.println( getFirstWord("tacocat")); //-1
        System.out.println( getFirstWord("java@@@is@@@awesome@@@"));
    }
    
}
