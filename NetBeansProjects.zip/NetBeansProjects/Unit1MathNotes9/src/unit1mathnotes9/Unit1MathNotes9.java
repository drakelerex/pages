/*
 * Andrew Emerick
 * 9/21/21
 * Unit 1 Notes on Math Operations
 */
package unit1mathnotes9;

public class Unit1MathNotes9 
{

    public static void main(String[] args) 
    {
        System.out.println( "samben" ); // samben
        System.out.println( "sam\tben" ); // sam    ben
        System.out.println( "sam\tben" ); // sam    ben
        System.out.println( "sam\\ben" ); // sam\ben
        System.out.println( 7 + 8 + 9 ); // 24
        
        System.out.println();
        
        System.out.println(3 + " " + 6); // 3 6
        System.out.println("\" samben  \""); // " samben  "
        System.out.println("\\t\\sam"); // \t\sam
        System.out.println("\\\\ben"); // //ben
        System.out.println(5 + " " + 6 + 7); // 5 13  actually: 5 67
    }
    
}
