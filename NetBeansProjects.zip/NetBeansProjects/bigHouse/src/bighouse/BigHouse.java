/*
 * Andrew Emerick
 * 11/15/21
 * Unit 4 Lab 3 - Big House - Draw A House
 */
package bighouse;

import javax.swing.JFrame;
import java.awt.Graphics;
import java.awt.Color;

public class BigHouse extends JFrame
{

    private static final int WIDTH = 1366;
    private static final int HEIGHT = 768;
    
    public BigHouse()
    {
        super("domi");
        setSize(WIDTH,HEIGHT);
        setBackground(Color.white);
        setVisible(true); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    
    public void paint(Graphics window)
    {
        window.setColor(Color.lightGray);
        window.fillRect(200, 200, 500, 500);
        window.setColor(Color.DARK_GRAY);
        window.fillRect(190, 200, 520, 100);
        window.setColor(Color.yellow);
        window.fillRect(300, 375, 75, 75);
        window.fillRect(500, 375, 75, 75);
        window.setColor(Color.PINK);
        window.fillRect(340, 625, 200, 75);
        window.setColor(Color.yellow);
        window.fillRect(400, 425, 75, 200);
    }

    public static void main(String[] args) 
    {
        BigHouse run = new BigHouse();
    }
    
}
