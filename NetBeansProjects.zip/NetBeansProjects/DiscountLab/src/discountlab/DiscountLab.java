/*
 * Andrew Emerick
 * Started on 5/1/22 D/M/Y
 * Determine the amount of discount a person should receive.
 */
package discountlab;

import java.util.Scanner;

public class DiscountLab {

    public static void main(String[] args) {
        Scanner moneydrain = new Scanner(System.in);
        DiscountLab strider = new DiscountLab();
        
        double discount = .15; // .15 is the same as 15%;
        double total;
        double tax = .0875;
        
        System.out.print("Enter the subtotal of your bill: ");
        double subTotal = moneydrain.nextDouble();
        if(subTotal > 2000){
            total = (subTotal*discount)*tax;
            System.out.println("The total of your bill with tax included is: $"+String.format("%.3f",total));
        }
        else {
            total = subTotal*tax;
            System.out.println("The total of your bill with tax included is: $"+String.format("%.3f",total));
        }
    }
    
}
