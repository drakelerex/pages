/*
 * Andrew Emerick
 * 19/1/22
 * Unit 7 - Notes on IndexOf
 */
package unit7notes3;

public class Unit7Notes3 {

    public static void main(String[] args) 
    {
        /* b e c a u s e
           0 1 2 3 4 5 6
        */
        
        String worm = "because";
        int index = worm.indexOf("au"); 
        System.out.println(index); // 3
        
        int i = worm.indexOf("bec"); 
        System.out.println(i); // 0
        
        int n = worm.indexOf("a"); 
        System.out.println(n); // 3
        
        int d = worm.indexOf("z"); 
        System.out.println(d); // -1
        
        int e = worm.indexOf("e"); 
        System.out.println(e); // 1, b/c it is the first occurance of e
        
        int x = worm.indexOf("because"); 
        System.out.println(x); // 0
    }
    
}
