/*
 * Andrew Emerick
 * 12/3/21
 * Unit 4 - Math Worksheet 1
 */
package unit4mathworksheet;

public class Unit4MathWorksheet {

    public static void main(String[] args) {
        double z = 94.32;
        long x = 98;
        int a = 9;
        int b = 4;
        char var = 'C';
        
        z = var + 5;
        System.out.println(a);
    }
    
}
