/*
 * Andrew Emerick
 * 18/1/22
 * Unit 7 - Notes on substrings
 */
package unit7notes2;

public class Unit7Notes2 
{

    public static void main(String[] args) 
    {
        String worm = "bookkeeper", sub = ""; //sub is an empty string
        sub = worm.substring(3);
        System.out.println(sub);
        
        sub = worm.substring(5);
        System.out.println(sub);
        
        sub = worm.substring(0);
        System.out.println(sub);
        
        // sub = worm.substring(12); out of range error, -2
        
        //substring prints from the index called to the end of the word
        
        /* b o o k k e e p e r
           0 1 2 3 4 5 6 7 8 9
        */
        
        sub = worm.substring(2, 5);
        System.out.println(sub); // okk
        
        sub = worm.substring(1, 6);
        System.out.println(sub); // ookke
        
        sub = worm.substring(7, 9);
        System.out.println(sub); // pe
        
        /* 
        substring will include the first parameter,
        and count up to but not include the second parameter 
        */
    }
    
}
