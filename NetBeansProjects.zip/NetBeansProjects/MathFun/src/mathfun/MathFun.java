/*
 * Andrew Emerick 
 * 12/13/21
 * This is FUN MATH
 */
package mathfun;

import java.util.Scanner;

public class MathFun {

    public int area(int length, int width)
    {
        return length*width;
    }
    
    public double triArea(double base, double height){
        return (height*base)/2;
    }
    
    public static void main(String[] args) {
        /* Create and instantiate the MathFun runner 
           You will also need a scanner */
        MathFun strider = new MathFun();
        Scanner parasite = new Scanner(System.in);
        
        // Ask the user for two integers
        System.out.print("Enter an integer: ");
        int num1 = parasite.nextInt();
        
        System.out.print("Enter another integer: ");
        int num2 = parasite.nextInt();
        
        System.out.println("The larger of the two numbers is "+Math.max(num1, num2));
        System.out.println("If your two numbers were dimensions of a rectangle, the area would be "+strider.area(num1, num2));
        
        System.out.println("If your two numbers were dimensions of a triangle, the area would be "+strider.triArea(num1, num2));
    }
    
}
