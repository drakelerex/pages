/*
 * Andrew Emerick
 * 22/12/21
 * Unit 6 Notes on If Else statements
 */
package unit6notes2;

public class Unit6Notes2 
{

    public static void main(String[] args) 
    {
        double grade = 99.9;
        
        if(grade >= 100) // conditional statement, boolean, T or F
        {
            System.out.println("Mind Blowing!");
        }
        
        else if(grade >= 90 && grade <= 99) // 90 <= grade <= 99 DOES NOT WORK!!!
        {
            System.out.println("Great Work!");
        }
        
        else if(grade >= 80 && grade <= 89)
        {
            System.out.println("Pretty ok, good work.");
        }
        
        else if(grade >= 70 && grade <= 79)
        {
            System.out.println("You passed!");
        }
        
        else if(grade >= 60 && grade <= 69)
        {
            System.out.println("Better start studying!");
        }
        
        else// Don't need conditionals (T or F) for last term
        {
            System.out.println("Enjoy summer school!");
        }
    }
    
}
