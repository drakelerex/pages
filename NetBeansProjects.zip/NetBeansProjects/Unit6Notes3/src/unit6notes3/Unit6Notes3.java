/*
 * Andrew Emerick
 * 3/1/22
 * Unit 6 - Notes on Nested if Statements
 */
package unit6notes3;

public class Unit6Notes3 {

    public static void main(String[] args) {
        
        double grade = 85;
        
        if(grade >= 90) // 90 <= grade <= 99 DOES NOT WORK!!!
        {
            if(grade >= 97)
                System.out.println("A+");
            if(grade <= 96 && grade >= 93)
                System.out.println("A");
            else if((grade <= 92 && grade >= 90))
                System.out.println("A-");
        }
        else if(grade >= 80)
        {
            if(grade >= 87)
                System.out.println("B+");
            else if(grade <= 82)
                System.out.println("B-");
            else
                System.out.println("B-");
        }
        else if(grade >= 70 && grade <= 79)
        {
            System.out.println("You passed!");
        }
        else if(grade >= 60 && grade <= 69)
        {
            System.out.println("Better start studying!");
        }
        else// Don't need conditionals (T or F) for last term
        {
            System.out.println("Enjoy summer school!");
        }
    }
    
}
