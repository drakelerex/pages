/*
 * Andrew Emerick
 * 10/7/21
 * Unit 2 - Notes on min, max, and errors
 */
package unit2notes2;

public class Unit2Notes2 
{

    public static void main(String[] args) 
    {
        byte a = Byte.MIN_VALUE; // -128
        System.out.println(a);
        
        byte b = Byte.MAX_VALUE; // 127
        System.out.println(b);
        
        System.out.println(Integer.MIN_VALUE);
        System.out.println(Integer.MAX_VALUE);
        
        char c = Character.MIN_VALUE;
        System.out.println(c); //blank space
        
        char d = Character.MAX_VALUE;
        System.out.println(d);
        
        System.out.println((int)Character.MIN_VALUE);
        System.out.println((int)Character.MAX_VALUE);
    }
    
}
