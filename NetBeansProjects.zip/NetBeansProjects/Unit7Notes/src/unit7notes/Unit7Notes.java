/*
 * Andrew Emerick
 * 14/1/22
 * Unit 7 - Notes on Strings
 */
package unit7notes;

public class Unit7Notes 
{

    public static void main(String[] args) 
    {
        String horridFood = "brussel sprouts";
        String words = new String("are delicious."); // instantiating a new String
        
        System.out.println(horridFood + " " + words); // brussel sprouts are delicious.
        
        System.out.println( horridFood.indexOf('b')); //0
        System.out.println( horridFood.indexOf('w')); // -1, though there is no w in brussel sprouts, means it has no where else to go.
        
        System.out.println(horridFood.length()); // length gives the actual length, 0...1...2...3 is for storage, humans count at 1
    
        System.out.println(horridFood.charAt(4)); //s
        // System.out.println(horridFood.charAt(17)); // out of range error
    }
    
}
