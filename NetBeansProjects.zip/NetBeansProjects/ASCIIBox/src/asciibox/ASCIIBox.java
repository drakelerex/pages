/*
 * Andrew Emerick
 * 9/27/21
 * Period 9
 * ASCII Box - Draw a box using ascii characters
 */
package asciibox;

public class ASCIIBox 
{

    public static void main(String[] args) 
    {
        System.out.println("Andrew Emerick    9/27/21 \n");
        
        System.out.println("********************");
        System.out.println("*                  *");
        System.out.println("*                  *");
        System.out.println("*      [{}][{}]    *");
        System.out.println("*      [{}][{}]    *");
        System.out.println("*      [{}][{}]    *");
        System.out.println("********************");
        
    }
    
}