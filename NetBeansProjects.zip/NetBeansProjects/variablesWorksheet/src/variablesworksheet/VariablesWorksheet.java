/*
 * Andrew Emerick
 * 10/6/21
 * Variables worksheet 1
 */
package variablesworksheet;

public class VariablesWorksheet 
{

    public static void main(String[] args) 
    {
        int x = 128;
        System.out.println(x);
        
        x = -98;
        System.out.println(x);
        
        byte b = 24;
        System.out.println(b);
        
        char c = 97;
        System.out.println(c);
        
        double d = 9.9;
        System.out.println(d);
        d = 5.2;
        System.out.println(d);
        float f = 9.87f;
        System.out.println(f);
        short s = 350;
        System.out.println(s);
        int z = 'A'+5;
        System.out.println(z);
        c = 'A'+5;
        System.out.println(c);
        double w = 'a'+5;
        System.out.println(w);
        
    }
    
}
