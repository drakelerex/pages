/*
 * Andrew Emerick
 * 10/27/21
 * Period 9
 * Unit 3 Mad Libs - Write a program that will ask the user for a series of words.
 */
package madlibs;

import java.util.Scanner;

public class MadLibs {

    public static void main(String[] args) {
        Scanner pumpkinScan = new Scanner(System.in);
        
        String dWord1;
        String dWord2;
        String day;
        String animal;
        String animal2;
        String holiday;
        String fruit;
        String verb;
        String place;
        
        System.out.print("Enter ONLY 2 descriptive words: ");
        dWord1 = pumpkinScan.next();
        dWord2 = pumpkinScan.next();
        
        System.out.print("Enter a time of day (Morning, day, night, etc): ");
        day = pumpkinScan.next();
        
        pumpkinScan.nextLine();
        
        System.out.print("Enter a plural animal species: ");
        animal = pumpkinScan.nextLine();
        
        System.out.print("Enter another plural animal species: ");
        animal2 = pumpkinScan.nextLine();
        
        System.out.print("Enter a holiday: ");
        holiday = pumpkinScan.nextLine();
        
        System.out.print("Enter a fruit: ");
        fruit = pumpkinScan.next();
        
        System.out.print("Enter a past-tense verb: ");
        verb = pumpkinScan.next();
        
        System.out.print("Enter a place: ");
        place = pumpkinScan.next();
        
        System.out.print("\nIt was a "+dWord1+" and "+dWord2+" "+day+".");
        System.out.print("\nAnd there were all kinds of strange monsters outside, there were "+animal+" and "+animal2+" outside, 'tis to be expected on "+holiday+".");
        System.out.print("\nThen the "+fruit+" turned moldy, and the animals "+verb+" to the "+place+".");
    }
    
}