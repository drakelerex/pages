/*
 * Andrew Emerick
 * 11/17/21
 * Unit 4 - Lab 1 - Star And Stripes - Write a method for class Stars And Stripes
 */
package starsandstripes;

public class StarsAndStripes
{
    public void red()
    {
        System.out.print("********@@@@@@@@@@@@@@@@\n");
    }
    
    public void white()
    {
        System.out.print("********$$$$$$$$$$$$$$$$\n");
    }
    
    public void fullRed()
    {
        System.out.print("@@@@@@@@@@@@@@@@@@@@@@@@\n");
    }
    
    public void fullWhite()
    {
        System.out.print("$$$$$$$$$$$$$$$$$$$$$$$$\n");
    }
    
    public static void main(String[] args) 
    {
        StarsAndStripes flag = new StarsAndStripes();
        flag.red();
        flag.white();
        flag.red();
        flag.fullWhite();
        flag.fullRed();
        flag.fullWhite();
        flag.fullRed();
    }
    
}
