/*
 * Andrew Emerick
 * 10/21/21
 * Unit 3 Notes - Input
*/
package unit3notes;

// imports always go up here
import java.util.Scanner;

public class Unit3Notes 
{
    public static void main(String[] args) 
    {
        // creates a new Scanner called keyboard
        // specific to this program, allows for user input
        Scanner keyboard = new Scanner(System.in);
        
        System.out.print("What is your favorite number? ");
        int favNum = keyboard.nextInt();
        System.out.println("You chose "+favNum+"\n");
        
        System.out.print("Enter a decimal: ");
        double decimal = keyboard.nextDouble();
        System.out.println("Your decimal is "+decimal+"\n");
        
        System.out.print("What is your first name? ");
        String name = keyboard.next(); // one word String
        System.out.println("Hello, "+name+"! \n");
        
        // VERY IMPORTANT
        keyboard.nextLine(); // eats up the extra white space
        
        System.out.print("What is your full name? ");
        String fullName = keyboard.nextLine(); //multi-word string
        System.out.println("Hello, "+fullName+"! \n");
    }
    
}