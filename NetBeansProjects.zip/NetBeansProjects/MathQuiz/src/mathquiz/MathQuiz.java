/*
 * Andrew Emerick
 * 12/16/21
 * Intro to Jaba the huts math quiz
 */
package mathquiz;

public class MathQuiz {

    public static void main(String[] args) {
        System.out.println(Math.max(Math.min(9,5), 11));
    }
    
}
