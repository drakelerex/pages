/*
 * Andrew Emerick
 * 20/12/21
 * Unit 6 Notes - Notes on if statements
 */
package unit6notes1;

import java.util.Scanner;

public class Unit6Notes1 
{

    public static void main(String[] args) 
    {
        Scanner wrm = new Scanner(System.in);
        
        System.out.print("Enter your grade: ");
        double grade = wrm.nextDouble();
        
        if(grade >= 100) // conditional statement, boolean, T or F
        {
            System.out.println("Mind Blowing!");
        }
        
        if(grade >= 90 && grade <= 99) // 90 <= grade <= 99 DOES NOT WORK!!!
        {
            System.out.println("Great Work!");
        }
        
        if(grade >= 80 && grade <= 89)
        {
            System.out.println("Pretty ok, good work.");
        }
        
        if(grade >= 70 && grade <= 79)
        {
            System.out.println("You passed!");
        }
        
        if(grade >= 60 && grade <= 69)
        {
            System.out.println("Better start studying!");
        }
        
        if(grade <=59)
        {
            System.out.println("Enjoy summer school!");
        }
    }
    
}