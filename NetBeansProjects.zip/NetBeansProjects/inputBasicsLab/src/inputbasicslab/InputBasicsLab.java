/*
 * Andrew Emerick
 * 10/27/21
 * Unit 3 - Input Basics, Define, input and print some variables and their values
 */
package inputbasicslab;

import java.util.Scanner;

public class InputBasicsLab {

    public static void main(String[] args) {
        Scanner scanbat = new Scanner(System.in);
        
        double db1;
        int i1;
        float flt1;
        String word2;
        String word1;
        byte bite;
        String animal;
        
        System.out.print("Type a number between 10 and 100: ");
        bite = scanbat.nextByte();
        String candycorn = "You have "+bite+" candycorn";
        System.out.println(candycorn);
        System.out.print("Enter a decimal between 5.00 and 1095.00 with only two decimal places: ");
        db1 = scanbat.nextDouble();
        String expire = "they will expire in "+db1+" hours";
        System.out.println(candycorn+" and "+expire);
        
        System.out.print("\nEnter two words: ");
        word1 = scanbat.next();
        word2 = scanbat.next();
        System.out.println(word2+" "+word1);
        
        System.out.print("\nEnter a whole number below 700 and also enter a decimal ");
        i1 = scanbat.nextInt();
        flt1 = scanbat.nextFloat();
        System.out.println("You have "+i1+" computers, and you have only $"+flt1+" left");
        animal = scanbat.nextLine();
        System.out.println(animal);
        
    }
    
}
