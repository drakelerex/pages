/*
 * Andrew Emerick
 * 10/5/2021
 * Unit 2 - Variables
 * Types of data and how they are stored.
 */
package unit2notesperiod9;

public class Unit2NotesPeriod9 
{

    public static void main(String[] args) 
    {
        //Strings - word, phrase, sentence
        String fullName = "Andrew Emerick";
        System.out.println(fullName);
        
        //int - integers, whole #'s, can be negative
        int age = 14;  // declare and initialize
        System.out.println(age);
        
        int temp;  //declaring an int called temp
        temp = 64;    // initializing temp to 64
        System.out.println("The temperature today is " + temp);
        
        //double - decimals, any # of sig figs
        double totalBill = 12.34;
        System.out.println("$" + totalBill);
        
        /* 
        Naming Variables
            - must* begin with a letter, no spaces
                * oddly, can also start with a $
                - tempDay1, tempDay2, tempDay3
            - CamelCase is very helpful!
            - can contain a number, just not the first character
            - only allowed to use an _ underscore for punctuation
            - please please only use variables that make sense
        */
        
        //int one = 120.0; // you cannot store a decimal in an integer
        //System.out.println(one); // Loss Of Precision error
        
        double two = 34; // You CAN store an int in a double
        System.out.println(two); // it will add a .0 at the end
        
        float three = 23.32f; // f denotes that it is a float value
        System.out.println(three); // the f does not print out
        
        two = 27; //re-initialize a variable to a new value
        System.out.println(two); //27.0 because it is a double
        
        char alpha = 'A'; //characters go in single quote
        System.out.println(alpha); //A
        
        char numeric = 65; // 65 is the numeric equivalent of A
        System.out.println(numeric); //A
        
        char sum = 'A' + 3;
        System.out.println(sum); //A+3 = D (A, B, C, D)
        
        System.out.println('A' + 3); //68, char is an integer type
        System.out.println((char)('A' + 3));
        // this is the fix, to cast the numeric back to a char
        
        char sum2 = '&' + 23;
        System.out.println(sum2);
    }
    
}