/*
 * Andrew Emerick
 * 12/15/21
 * Calculate the perimeter of a rectangle
 */
package rectangle;

import java.util.Scanner;

public class Rectangle {

    public double perimeter(double l, double w)
    {
        return 2*(l+w);
    }
    
    public double area(double l, double w)
    {
        return l*w;
    }
    
    public static void main(String[] args) {
        Rectangle strider = new Rectangle();
        Scanner roundworm = new Scanner(System.in);
        
        System.out.print("Enter the length of your rectangle, in inches: ");
        double length = roundworm.nextDouble();
        System.out.print("Enter the width of your rectangle, in inches: ");
        double width = roundworm.nextDouble();
        
        System.out.println("The perimeter of your rectangle is "+strider.perimeter(length, width)+"in. and the area of your rectangle is "+strider.area(length, width)+"in");
    }
    
}
