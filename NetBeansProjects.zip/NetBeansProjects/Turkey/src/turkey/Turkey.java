/*
 * Andrew Emerick
 * November 3, 2021
 * Unit 4 - Methods
 */
package turkey;


public class Turkey {
    
    // THIS IS WHERE YOUR METHODS GO
    public void speak()
    {
        System.out.println("Gobble");
    }
    
    public void walk()
    {
        System.out.println("strut");
    }
    
    public void sayName()
    {
        System.out.println("Hello, my name is Captain Thanksgiving!");
    }
    
    public void sayGoodbye()
    {
        System.out.println("~gunshot~ GOBBLE!!!");
    }
    
    // THIS IS THE MAIN PART OF YOUR PROGRAM
    public static void main(String[] args) 
    {
        Turkey bird = new Turkey(); //creates a turkey
        
        bird.speak();
        bird.speak();
        bird.speak();
        bird.speak();
        bird.walk();
        bird.sayName();
        bird.sayGoodbye();
    }
    
}