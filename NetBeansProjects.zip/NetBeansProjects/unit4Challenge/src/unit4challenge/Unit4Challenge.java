/*
 * Andrew Emerick
 * 11/5/21
 * Unit 4 challenge - Write a program that sings happy birthday
 */
package unit4challenge;

import java.util.Scanner;

public class Unit4Challenge {
    // start of methods
    public void line()
    {
        System.out.println("Happy birthday to thee, ");
    }
    public void end()
    {
        System.out.println("happy birthday to you!");
    }
    
    public static void main(String[] args) {
       Unit4Challenge song = new Unit4Challenge();
       Scanner askName = new Scanner(System.in);
       String name;
       
       System.out.print("What is your name? ");
       name = askName.nextLine();
       
       System.out.println("");
       song.line();
       song.line();
       song.line();
       System.out.println("Happy birthday dear "+name+", ");
       song.end();
    }
    
}
