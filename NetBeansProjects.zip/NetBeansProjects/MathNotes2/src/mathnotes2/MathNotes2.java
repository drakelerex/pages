/*
 * Andrew Emerick
 * 12/2/21
 * Unit 5 - Math Notes - casting
 */
package mathnotes2;

public class MathNotes2 
{
    public static void main(String[] args) 
    {
        // Casting - a fast way to turn doubles into integers
        System.out.println(3.14159265358979);
        System.out.println((int)3.14159265358979); //3
        System.out.println((int)3.999999999999999999999999); // 3, aware of LOP
        System.out.println((double)3);
        
        // Casting - used to create compatibility between different data types
        int num = 0; // 32 bit memory int
        long bigInt = 350; // 64 bit memory int
        double dec = 7.16; // 64 bit memory real
        
        // num = dec; // ILLEGAL - double to int
        // num = bigInt; // ILLEGAL - long to int
        num = (int)dec;
        System.out.println(num);
        num = (int)bigInt;
        System.out.println(num);
        bigInt = (long)dec;
        System.out.println(bigInt);
    }
}
