/*
 * Andrew Emerick
 * 9/28/21
 * Period 9
 * ASCII Triangle- Draw a Triangle using ascii characters
 */
package asciitri;

public class Asciitri 
{

    public static void main(String[] args) 
    {
        System.out.println("********************");
        System.out.println(" *    @@    @@    * ");
        System.out.println("  *   @@    @@   *  ");
        System.out.println("   *            *   ");
        System.out.println("    *          *    ");
        System.out.println("     *    ^   *     ");
        System.out.println("      *   ^  *      ");
        System.out.println("       *   *        ");
        System.out.println("        * *         ");
        System.out.println("        ***         ");
       
    }
    
}
