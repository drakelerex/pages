/*
 * Andrew Emerick
 * 10/22/21
 * Unit 3 Challenge - Write a program that takes 3 integers from a single command.
 */
package unit3challenge;

import java.util.Scanner;

public class Unit3Challenge {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        
        System.out.print("Enter 3 integers: ");
        int i1 = kb.nextInt();
        int i2 = kb.nextInt();
        int i3 = kb.nextInt();
        int sum = i1+i2+i3;
        System.out.println("You chose "+i1+", "+i2+", "+"and "+i3+" and the sum of your numbers is "+sum);
        
    }
    
}
