/*
 * Andrew Emerick
 * 11/1/21
 * Unit 4 - Methods
 * November 1, 2021
*/
package turkeytalk;

public class TurkeyTalk 
{
    public void talk()
    {
        System.out.println("Gobble");
    }
    
    public void walk()
    {
        System.out.println("waddle");
    }
    public static void main(String[] args) 
    {
        TurkeyTalk bird = new TurkeyTalk();
        
        bird.talk();
        bird.talk();
        bird.talk();
        bird.talk();
        bird.walk();
        bird.walk();
        /*bird.sayHello();
        bird.eat();*/
    }
    
}
