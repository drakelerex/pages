/*
 * Andrew Emerick
 * 12/9/21
 * Unit 5 Challenge- Create a program that finds the average of 3 grades
 */
package unit5challenge;

import java.util.Scanner;

public class Unit5Challenge 
{
    
    public double average(double iGrade1, double iGrade2, double iGrade3)
    {
        return (iGrade1+iGrade2+iGrade3)/3;
    }
    
    public static void main(String[] args) 
    {
        Scanner parasitoid = new Scanner(System.in);
        Unit5Challenge school = new Unit5Challenge();
        
        System.out.print("Enter the First Grade: ");
        double grade1 = parasitoid.nextDouble();
        System.out.print("\nEnter the Second Grade: ");
        double grade2 = parasitoid.nextDouble();
        System.out.print("\nEnter the Third Grade: ");
        double grade3 = parasitoid.nextDouble();
        System.out.println("Your average is " + school.average(grade1,grade2,grade3));
        
    }
    
}
