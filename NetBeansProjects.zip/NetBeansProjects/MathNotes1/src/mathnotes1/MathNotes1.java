/*
 * Andrew Emerick
 * December 1, 2021
 * Unit 5 - Math Returns
 * Notes on math functions, modulus, shortcuts
 */
package mathnotes1;

public class MathNotes1 
{
    public static void main(String[] args) 
    {
        // integer math
        int div1 = 10/2;
        System.out.println(div1); // 5, CORRECT
        
        int div2 = 10/3;
        System.out.println(div2); // 3, INCORRECT
        
        // real math
        double div3 = 10/3;
        System.out.println(div3); // 3.0, INCORRECT
        
        double div4 = 10/3.0;
        System.out.println(div4); // 3.333333.., CORRECT
        
        System.out.println("");
        
        // Modulus - gives the remainder in a division problem
        
        System.out.println("5%5 = " + 5%5); // 0
        System.out.println("5%4 = " + 5%4); // 1
        System.out.println("5%3 = " + 5%3); // 2
        System.out.println("5%2 = " + 5%2); // 1
        System.out.println("5%1 = " + 5%1); // 0
        // System.out.println("5%0 = " + 5%0); // ERROR, cannot divide by zero
        
        System.out.println();
        
        //Shortcuts
        int num = 10;
        System.out.println(num); //10
        
        num += 5;
        System.out.println(num); //15
        
       num *= 2;
       System.out.println(num); //30
       
       num++;
       System.out.println(num); // 31
       num--;
       num--;
       System.out.println(num); // 29
       
       System.out.println();
       
       //REMINDFR
       char x = 'A';
       System.out.println(x);
       
       int y = 'A';
       System.out.println(y); //65
       
       int z = 'a';
       System.out.println(z); // 97
       
       x++; // A + 1 = B
       y++; // 65 + 1 = 66
       z++; // 97 + 1 = 98
       
       System.out.println(x);
       System.out.println(y);
       System.out.println(z);
    }
}
