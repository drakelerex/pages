/*
 * Andrew Emerick
 * 11/8/21
 * Graphics Practice
 */
package graphicspractice;

// this is where imports and setups go
import javax.swing.JFrame;

public class GraphicsPractice extends JFrame // this is where you set up stuff
{
    private static final int WIDTH = 640; // initialize and declare
    private static final int HEIGHT = 480;
    
    public GraphicsPractice()
    { // curly brackets also called braces
        setSize(WIDTH, HEIGHT);
        
        setVisible(true);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public static void main(String[] args) // this is where you do stuff
    {
        GraphicsPractice prac = new GraphicsPractice();
    }
    
}
