/*  
 * Andrew Emerick
 * 10/12/21
 * Variables - define and print some variables
 */
package variableslab;

public class VariablesLab {

    public static void main(String[] args) {
        // Byte
        byte byteSize = Byte.SIZE;
        byte byteMin = Byte.MIN_VALUE;
        byte byteMax = Byte.MAX_VALUE;
        // Short
        byte shortSize = Short.SIZE;
        short shortMin = Short.MIN_VALUE;
        short shortMax = Short.MAX_VALUE;
        // Integer
        byte intSize = Integer.SIZE;
        int intMin = Integer.MIN_VALUE;
        int intMax = Integer.MAX_VALUE;
        // Long
        byte longSize = Long.SIZE;
        long longMin = Long.MIN_VALUE;
        long longMax = Long.MAX_VALUE;
        // Float
        byte fltSize = Float.SIZE;
        float fltMin = Float.MIN_VALUE;
        float fltMax = Float.MAX_VALUE;
        // Double
        byte dblSize = Double.SIZE;
        double dblMin = Double.MIN_VALUE;
        double dblMax = Double.MAX_VALUE;
        //Character
        byte charSize = Character.SIZE;
        int charMin = Character.MIN_VALUE;
        int charMax = Character.MAX_VALUE;
        //Boolean
        byte boolSize = 1;
        boolean boolMin = false;
        boolean boolMax = true;
        
        System.out.println("-----------------------------------------------------------------------");
        System.out.println("| Andrew Emerick                                              10/8/21 |");
        System.out.println("|---------------------------------------------------------------------|");
        System.out.println("| Var Type | Bits |         Min Value        |        Max Value       |");
        System.out.println("|---------------------------------------------------------------------|");
        System.out.println("|   Byte   |  " + byteSize + "   |          " + byteMin + "            |         " + byteMax + "            |");
        System.out.println("|   Short  |  " + shortSize + "  |         " + shortMin + "           |         " + shortMax + "          |");
        System.out.println("|  Integer |  " + intSize + "  |       " + intMin + "        |       " + intMax + "       |");
        System.out.println("|   Long   |  " + longSize + "  |   " + longMin + "   |  " + longMax + "   |");
        System.out.println("|   Float  |  " + fltSize + "  |         " + fltMin + "          |      " + fltMax + "      |");
        System.out.println("|   Double |  " + dblSize + "  |         " + dblMin + "         | " + dblMax + " |");
        System.out.println("|   Char   |  " + charSize + "  |          " + charMin + " (ASCII)       |       " + charMax + " (ASCII)    |");
        System.out.println("|  Boolean |  " + boolSize + "   |          " + boolMin + "           |         " + boolMax + "           |");
        System.out.println("-----------------------------------------------------------------------");
    }
    
}
