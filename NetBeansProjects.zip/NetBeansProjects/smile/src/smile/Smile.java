/*
 * Andrew Emerick
 * 11/18/21
 * Unit 4 - Lab 2 - Draw a vampire face.
 */
package smile;

import javax.swing.JFrame;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Polygon;

public class Smile extends JFrame
{
    private static final int WIDTH = 1366;
    private static final int HEIGHT = 768;
    
    public Smile()
    {
        super("Your funniest nightmare");
        setSize(WIDTH,HEIGHT);
        setBackground(Color.white);
        setVisible(true); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // note the cosole will now say that the application has terminated
    }
    
    public void paint(Graphics window)
    {
        window.setColor(Color.LIGHT_GRAY);
        window.fillOval(400, 150, 500, 500);
        window.setColor(Color.red);
        window.fillArc(500, 300, 100, 40, 40, 100);
        window.fillArc(700, 300, 100, 40, 40, 100);
        window.setColor(Color.BLACK);
        window.drawLine(550, 450, 800, 450);
        window.setColor(Color.white);
        int[] xPoints = {610, 600, 620}; 
        int[] yPoints = {500, 450, 450};
        int nPoints = 3;
        Polygon triangle = new Polygon(xPoints, yPoints, nPoints);
        window.fillPolygon(triangle);
    }
    
    public static void main(String[] args) 
    {
        Smile run = new Smile();
    }
    
}
